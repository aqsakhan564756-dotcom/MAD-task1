#include <iostream>
#include <string>
using namespace std;

class Property {
public:
    string location;

    void setLocation(string loc) {
        location = loc;
    }
};

class Commercial : public Property {
public:
    int floorArea;

    void setCommercial(string loc, int area) {
        setLocation(loc);
        floorArea = area;
    }
};

class ShoppingMall : public Commercial {
public:
    int totalShops;

    void setMall(string loc, int area, int shops) {
        setCommercial(loc, area);
        totalShops = shops;
    }
    void displayMall() {
        cout << "Location: " << location << endl;
        cout << "Area: " << floorArea << " sq ft" << endl;
        cout << "Shops: " << totalShops << endl;
    }
};

int main() {
    ShoppingMall sm;
    sm.setMall("Gulberg Lahore", 50000, 120);
    sm.displayMall();
    return 0;
}
