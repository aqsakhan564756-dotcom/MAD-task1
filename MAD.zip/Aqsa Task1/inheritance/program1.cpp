#include <iostream>
#include <string>
using namespace std;

class SchoolMember {
public:
    string fullName;

    void setName(string n) {
        fullName = n;
    }
};

class HeadMaster : public SchoolMember {
public:
    int experienceYears;

    void setHead(string n, int exp) {
        setName(n);
        experienceYears = exp;
    }
    void showHead() {
        cout << "Headmaster: " << fullName << endl;
        cout << "Experience: " << experienceYears << " years" << endl;
    }
};

int main() {
    HeadMaster hm;
    hm.setHead("Mr. Tariq", 15);
    hm.showHead();
    return 0;
}
