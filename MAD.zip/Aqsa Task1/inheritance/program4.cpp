#include <iostream>
using namespace std;

class QuizScore {
public:
    int quizMarks;

    void setQuiz(int q) {
        quizMarks = q;
    }
};

class AssignmentScore {
public:
    int assignMarks;

    void setAssign(int a) {
        assignMarks = a;
    }
};

class SessionalGrade : public QuizScore, public AssignmentScore {
public:
    void printSessional() {
        cout << "Quiz: " << quizMarks << endl;
        cout << "Assignment: " << assignMarks << endl;
        cout << "Sessional Total: " << quizMarks + assignMarks << endl;
    }
};

int main() {
    SessionalGrade sg;
    sg.setQuiz(18);
    sg.setAssign(22);
    sg.printSessional();
    return 0;
}
