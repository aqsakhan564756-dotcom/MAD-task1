#include <iostream>
using namespace std;

class Fish {
public:
    void swim() {
        cout << "Fish swims in water" << endl;
    }
};

class Salmon : public Fish {
public:
    void jump() {
        cout << "Salmon leaps against the current" << endl;
    }
};

class Shark : public Fish {
public:
    void bite() {
        cout << "Shark hunts with sharp teeth" << endl;
    }
};

int main() {
    Salmon s;
    s.swim();
    s.jump();

    Shark sh;
    sh.swim();
    sh.bite();
    return 0;
}
