#include <iostream>
using namespace std;

class ShapeDrawer {
public:
    virtual void render() = 0;
};

class LineDrawer : public ShapeDrawer {
public:
    void render() {
        cout << "Rendering a straight line on screen" << endl;
    }
};

class OvalDrawer : public ShapeDrawer {
public:
    void render() {
        cout << "Rendering an oval curve on screen" << endl;
    }
};

int main() {
    LineDrawer ld;
    OvalDrawer od;
    ld.render();
    od.render();
    return 0;
}
