#include <iostream>
using namespace std;

class FoodDelivery {
public:
    virtual void placeOrder() = 0;
};

class FoodPanda : public FoodDelivery {
public:
    void placeOrder() {
        cout << "Order placed on Foodpanda app" << endl;
    }
};

class Cheetay : public FoodDelivery {
public:
    void placeOrder() {
        cout << "Order placed on Cheetay rider service" << endl;
    }
};

int main() {
    FoodPanda fp;
    Cheetay ch;
    fp.placeOrder();
    ch.placeOrder();
    return 0;
}
