#include <iostream>
using namespace std;

class BrowserTab {
public:
    virtual void loadPage() = 0;
};

class ChromeTab : public BrowserTab {
public:
    void loadPage() {
        cout << "Loading web page with Chrome V8 engine" << endl;
    }
};

class FirefoxTab : public BrowserTab {
public:
    void loadPage() {
        cout << "Loading web page with Firefox Gecko engine" << endl;
    }
};

int main() {
    ChromeTab ct;
    FirefoxTab ft;
    ct.loadPage();
    ft.loadPage();
    return 0;
}
