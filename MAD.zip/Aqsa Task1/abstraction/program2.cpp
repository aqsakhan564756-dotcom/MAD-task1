#include <iostream>
using namespace std;

class SecurityLock {
public:
    virtual void unlock() = 0;
};

class KeyLock : public SecurityLock {
public:
    void unlock() {
        cout << "Unlocked using physical metal key" << endl;
    }
};

class DigitalLock : public SecurityLock {
public:
    void unlock() {
        cout << "Unlocked using 4-digit passcode keypad" << endl;
    }
};

int main() {
    KeyLock kl;
    DigitalLock dl;
    kl.unlock();
    dl.unlock();
    return 0;
}
