#include <iostream>
#include <string>
using namespace std;

class BusTicket {
private:
    int ticketNumber;
    int fare;

public:
    void setTicket(int no, int f) {
        ticketNumber = no;
        fare = f;
    }
    int getFare() {
        return fare;
    }
    void displayTicket() {
        cout << "Ticket No: " << ticketNumber << endl;
        cout << "Fare: " << fare << " Rs" << endl;
    }
};

int main() {
    BusTicket bt;
    bt.setTicket(804, 1500);
    bt.displayTicket();
    return 0;
}
