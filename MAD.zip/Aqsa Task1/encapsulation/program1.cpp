#include <iostream>
#include <string>
using namespace std;

class CinemaSeat {
private:
    int seatRow;
    char seatCol;
    bool isBooked;

public:
    void setSeat(int r, char c) {
        seatRow = r;
        seatCol = c;
        isBooked = false;
    }
    void reserve() {
        isBooked = true;
    }
    void checkStatus() {
        cout << "Seat: " << seatRow << seatCol << endl;
        if (isBooked) {
            cout << "Status: Reserved" << endl;
        } else {
            cout << "Status: Available" << endl;
        }
    }
};

int main() {
    CinemaSeat s;
    s.setSeat(5, 'D');
    s.checkStatus();
    s.reserve();
    s.checkStatus();
    return 0;
}
