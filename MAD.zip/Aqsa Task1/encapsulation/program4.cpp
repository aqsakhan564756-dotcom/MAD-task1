#include <iostream>
#include <string>
using namespace std;

class FitnessTracker {
private:
    int caloriesBurned;

public:
    void initTracker() {
        caloriesBurned = 0;
    }
    void exercise(int cal) {
        caloriesBurned = caloriesBurned + cal;
    }
    int getCalories() {
        return caloriesBurned;
    }
    void report() {
        cout << "Total Calories Burned: " << caloriesBurned << " kcal" << endl;
    }
};

int main() {
    FitnessTracker ft;
    ft.initTracker();
    ft.exercise(350);
    ft.exercise(150);
    ft.report();
    return 0;
}
