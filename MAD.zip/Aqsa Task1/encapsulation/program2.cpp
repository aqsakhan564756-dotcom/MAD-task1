#include <iostream>
#include <string>
using namespace std;

class Camera {
private:
    string brand;
    int megaPixels;

public:
    void setCamera(string b, int mp) {
        brand = b;
        megaPixels = mp;
    }
    string getBrand() {
        return brand;
    }
    int getMP() {
        return megaPixels;
    }
    void showSpecs() {
        cout << "Camera: " << brand << endl;
        cout << "Resolution: " << megaPixels << " MP" << endl;
    }
};

int main() {
    Camera c;
    c.setCamera("Canon", 24);
    c.showSpecs();
    return 0;
}
