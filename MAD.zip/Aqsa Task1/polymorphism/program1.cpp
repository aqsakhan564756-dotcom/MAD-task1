#include <iostream>
using namespace std;

class PrinterOutput {
public:
    void output(int number) {
        cout << "Printing integer: " << number << endl;
    }
    void output(double decimalVal) {
        cout << "Printing decimal: " << decimalVal << endl;
    }
    void output(char characterVal) {
        cout << "Printing char: " << characterVal << endl;
    }
};

int main() {
    PrinterOutput po;
    po.output(99);
    po.output(45.67);
    po.output('K');
    return 0;
}
