#include <iostream>
using namespace std;

class VehicleFare {
public:
    virtual void charge() {
        cout << "Base transport fare: 50" << endl;
    }
};

class TaxiFare : public VehicleFare {
public:
    void charge() {
        cout << "Taxi metered fare: 300" << endl;
    }
};

class RickshawFare : public VehicleFare {
public:
    void charge() {
        cout << "Rickshaw fare: 150" << endl;
    }
};

int main() {
    VehicleFare* vf;
    TaxiFare tf;
    RickshawFare rf;

    vf = &tf;
    vf->charge();

    vf = &rf;
    vf->charge();

    return 0;
}
