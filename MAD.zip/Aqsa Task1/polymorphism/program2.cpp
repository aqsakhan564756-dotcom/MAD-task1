#include <iostream>
using namespace std;

class DistanceLength {
public:
    int meters;

    DistanceLength() {
        meters = 0;
    }
    DistanceLength(int m) {
        meters = m;
    }
    DistanceLength operator+(DistanceLength d) {
        DistanceLength res;
        res.meters = meters + d.meters;
        return res;
    }
    void show() {
        cout << "Distance: " << meters << " meters" << endl;
    }
};

int main() {
    DistanceLength d1(150);
    DistanceLength d2(250);
    DistanceLength total = d1 + d2;
    total.show();
    return 0;
}
