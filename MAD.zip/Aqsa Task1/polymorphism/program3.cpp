#include <iostream>
using namespace std;

class Instrument {
public:
    virtual void playNote() {
        cout << "General instrument sound" << endl;
    }
};

class Piano : public Instrument {
public:
    void playNote() {
        cout << "Piano plays melody keys" << endl;
    }
};

class Guitar : public Instrument {
public:
    void playNote() {
        cout << "Guitar strums chords" << endl;
    }
};

int main() {
    Instrument* inst;
    Piano p;
    Guitar g;

    inst = &p;
    inst->playNote();

    inst = &g;
    inst->playNote();

    return 0;
}
